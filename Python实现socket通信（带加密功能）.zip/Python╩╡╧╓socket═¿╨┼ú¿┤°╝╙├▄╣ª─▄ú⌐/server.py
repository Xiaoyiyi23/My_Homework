# -*- codeing = utf-8 -*-
# @Time : 2022/8/8 14:29

import socket
from cryptography.fernet import Fernet

# 创建服务器端套接字
sk = socket.socket()

# 把地址绑定到套接字
sk.bind(('127.0.0.1', 8898))

# 监听链接
sk.listen()

# 接受客户端链接
conn, addr = sk.accept()

while True:
    # 接收客户端信息
    ret = conn.recv(1024)

    # 处理接收的信息
    key = ret[0:44]
    message2 = ret[44:]

    # 进行解密
    cipher = Fernet(key)
    message = cipher.decrypt(message2)

    # 结束会话
    if message == b'quit':
        conn.send(b'quit')
        break


    # 打印客户端信息
    print("来自客户端的消息：%s\n" % message.decode('utf-8'))

    # 输入新的信息
    message1 = input('请输入要发送的消息：')
    message1 = bytes(message1, encoding="utf-8")

    # 结束会话
    if message1 == b'quit':
        conn.send(b'quit')
        break

    # Fernet对称加密
    # 生成秘钥cipher_key
    cipher_key = Fernet.generate_key()
    print("此次传输数据使用的加密密钥为：%s"%cipher_key)

    # 进行加密
    cipher = Fernet(cipher_key)
    encrypted_text = cipher.encrypt(message1)

    # 密钥和密文打包
    message1 = cipher_key + encrypted_text

    # 发送信息
    conn.send(message1)
    print("数据已成功发送...\n")

# 关闭客户端链接
conn.close()
# 关闭服务器套接字
sk.close()
