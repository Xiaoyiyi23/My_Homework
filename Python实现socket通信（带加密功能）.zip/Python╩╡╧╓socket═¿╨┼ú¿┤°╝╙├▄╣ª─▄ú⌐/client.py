# -*- codeing = utf-8 -*-
# @Time : 2022/8/8 10:20

import socket
from cryptography.fernet import Fernet

# 创建客户端套接字
sk = socket.socket()

# 尝试连接服务器
sk.connect(('127.0.0.1', 8898))

print("如果想退出程序，请发送quit关键字")

while True:
    # 信息发送
    message1 = input('请输入要发送的消息：')
    message1 = bytes(message1, encoding="utf-8")
    message3 = message1

    # Fernet对称加密
    # 生成秘钥cipher_key
    cipher_key = Fernet.generate_key()
    print("此次传输数据使用的加密密钥为：%s" % cipher_key)

    cipher = Fernet(cipher_key)
    # 进行加密
    encrypted_text = cipher.encrypt(message1)

    # 密钥和密文打包
    message1 = cipher_key + encrypted_text

    # 发送信息
    sk.send(message1)
    print("数据已成功发送...\n")

    # 结束会话
    if message3 == b'quit':
        sk.send(b'quit')
        break

    # 信息接收
    ret = sk.recv(1024)

    # 处理接收的信息
    key = ret[0:44]
    message2 = ret[44:]

    # 进行解密
    cipher = Fernet(key)
    message = cipher.decrypt(message2)

    # 信息打印
    print("来自服务器的消息：%s\n" % message.decode('utf-8'))
# 关闭客户端套接字
sk.close()
