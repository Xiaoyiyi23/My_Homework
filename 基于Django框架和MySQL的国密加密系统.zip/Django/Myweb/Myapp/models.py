from django.db import models

# Create your models here.

from django.db import models


# Create your models here.  User对应数据库中的表
class User(models.Model):
    # 明文哈希值
    plaintext_hash = models.CharField(max_length=200)
    # 密文哈希值
    ciphertext_hash = models.CharField(max_length=200)
    # 模式
    model = models.CharField(max_length=100)
