from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.shortcuts import render
from .models import User
from django.db import models
from rest_framework.views import APIView
from rest_framework.response import Response
from gmssl import sm2, sm3
from gmssl import func
from random import SystemRandom
from gmssl.sm4 import CryptSM4, SM4_ENCRYPT, SM4_DECRYPT
import random
import string
import codecs

'''
class EncryptAdd(APIView):
    
    @staticmethod
    def get(request):
        req = request.query_params.dict()  # 前端给的json包数据
        plaintext_hash = req["plaintext_hash"]

        student_id = User.objects.filter(student_name=plaintext_hash).values("student_id")  # 提取数据表中数据
        return Response(student_id)  # 返回数据，这里由于提取数据表中数据直接就是jason格式所以可以直接传，其他的需要转为json格式
    

    @staticmethod
    def post(request):
        text = request.POST.get("plaintext")
        print(str(text))

        req = request.data  # 前端给的json包数据
        plaintext_hash = req["plaintext_hash"]  # 明文哈希
        ciphertext_hash = req["ciphertext_hash"]  # 密文哈希

        User(plaintext_hash=plaintext_hash, ciphertext_hash=ciphertext_hash).save()  # 保存数据

        return Response()  # 不需要返回数据
'''
'''
def process(request):
'''


# 系统首页显示模块

def index(request):
    return render(request, 'encryptweb.html')


# 验签页面显示模块

def sign(request):
    return render(request, 'sign.html')


# 后端验签模块

def testsign(request):
    data = request.FILES['plaintext']
    sign = request.POST['sign']
    public_key = request.POST['pubkey']
    # private_key = request.POST['prikey']
    private_key = ' '
    # name = str(data)
    data = str(data.read(), encoding="utf8")
    data = bytes(data, encoding="utf8")  # str转bytes

    sm2_crypt = sm2.CryptSM2(public_key=public_key, private_key=private_key)

    result = sm2_crypt.verify(sign, data)
    return render(request, 'testsign.html', context={'pubk': result})


# 后端加密模块

def process(request):
    # if request.method == 'POST':

    data = request.FILES['plaintext']
    name = str(data)
    data = str(data.read(), encoding="utf8")
    data = bytes(data, encoding="utf8")  # str转bytes
    mod = 2
    mod = request.POST['sex']
    mod = int(mod)
    public_key = ' '
    private_key = ' '
    prik = ' '
    pubk = ' '
    key = ' '

    class CurveFp:
        def __init__(self, A, B, P, N, Gx, Gy, name):
            self.A = A
            self.B = B
            self.P = P
            self.N = N
            self.Gx = Gx
            self.Gy = Gy
            self.name = name

    sm2p256v1 = CurveFp(
        name="sm2p256v1",
        A=0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC,
        B=0x28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93,
        P=0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF,
        N=0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123,
        Gx=0x32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7,
        Gy=0xBC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0
    )

    def multiply(a, n, N, A, P):
        return fromJacobian(jacobianMultiply(toJacobian(a), n, N, A, P), P)

    def add(a, b, A, P):
        return fromJacobian(jacobianAdd(toJacobian(a), toJacobian(b), A, P), P)

    def inv(a, n):
        if a == 0:
            return 0
        lm, hm = 1, 0
        low, high = a % n, n
        while low > 1:
            r = high // low
            nm, new = hm - lm * r, high - low * r
            lm, low, hm, high = nm, new, lm, low
        return lm % n

    def toJacobian(Xp_Yp):
        Xp, Yp = Xp_Yp
        return (Xp, Yp, 1)

    def fromJacobian(Xp_Yp_Zp, P):
        Xp, Yp, Zp = Xp_Yp_Zp
        z = inv(Zp, P)
        return ((Xp * z ** 2) % P, (Yp * z ** 3) % P)

    def jacobianDouble(Xp_Yp_Zp, A, P):
        Xp, Yp, Zp = Xp_Yp_Zp
        if not Yp:
            return (0, 0, 0)
        ysq = (Yp ** 2) % P
        S = (4 * Xp * ysq) % P
        M = (3 * Xp ** 2 + A * Zp ** 4) % P
        nx = (M ** 2 - 2 * S) % P
        ny = (M * (S - nx) - 8 * ysq ** 2) % P
        nz = (2 * Yp * Zp) % P
        return (nx, ny, nz)

    def jacobianAdd(Xp_Yp_Zp, Xq_Yq_Zq, A, P):
        Xp, Yp, Zp = Xp_Yp_Zp
        Xq, Yq, Zq = Xq_Yq_Zq
        if not Yp:
            return (Xq, Yq, Zq)
        if not Yq:
            return (Xp, Yp, Zp)
        U1 = (Xp * Zq ** 2) % P
        U2 = (Xq * Zp ** 2) % P
        S1 = (Yp * Zq ** 3) % P
        S2 = (Yq * Zp ** 3) % P
        if U1 == U2:
            if S1 != S2:
                return (0, 0, 1)
            return jacobianDouble((Xp, Yp, Zp), A, P)
        H = U2 - U1
        R = S2 - S1
        H2 = (H * H) % P
        H3 = (H * H2) % P
        U1H2 = (U1 * H2) % P
        nx = (R ** 2 - H3 - 2 * U1H2) % P
        ny = (R * (U1H2 - nx) - S1 * H3) % P
        nz = (H * Zp * Zq) % P
        return (nx, ny, nz)

    def jacobianMultiply(Xp_Yp_Zp, n, N, A, P):
        Xp, Yp, Zp = Xp_Yp_Zp
        if Yp == 0 or n == 0:
            return (0, 0, 1)
        if n == 1:
            return (Xp, Yp, Zp)
        if n < 0 or n >= N:
            return jacobianMultiply((Xp, Yp, Zp), n % N, N, A, P)
        if (n % 2) == 0:
            return jacobianDouble(jacobianMultiply((Xp, Yp, Zp), n // 2, N, A, P), A, P)
        if (n % 2) == 1:
            return jacobianAdd(jacobianDouble(jacobianMultiply((Xp, Yp, Zp), n // 2, N, A, P), A, P), (Xp, Yp, Zp),
                               A, P)

    class PrivateKey:
        def __init__(self, curve=sm2p256v1, secret=None):
            self.curve = curve
            self.secret = secret or SystemRandom().randrange(1, curve.N)

        def publicKey(self):
            curve = self.curve
            xPublicKey, yPublicKey = multiply((curve.Gx, curve.Gy), self.secret, A=curve.A, P=curve.P, N=curve.N)
            return PublicKey(xPublicKey, yPublicKey, curve)

        def toString(self):
            return "{}".format(str(hex(self.secret))[2:].zfill(64))

    class PublicKey:
        def __init__(self, x, y, curve):
            self.x = x
            self.y = y
            self.curve = curve

        def toString(self, compressed=True):
            return {
                True: str(hex(self.x))[2:],
                False: "{}{}".format(str(hex(self.x))[2:].zfill(64), str(hex(self.y))[2:].zfill(64))
            }.get(compressed)

    def create_key_pair():
        priKey = PrivateKey()
        pubKey = priKey.publicKey()
        return priKey.toString(), pubKey.toString(compressed=False)

    # if __name__ == "__main__":
    priKey = PrivateKey()
    pubKey = priKey.publicKey()

    # 16进制的公钥和私钥
    private_key = priKey.toString()
    public_key = pubKey.toString(compressed=False)
    sm2_crypt = sm2.CryptSM2(
        public_key=public_key, private_key=private_key)

    if mod == 2:
        '''
        class CurveFp:
            def __init__(self, A, B, P, N, Gx, Gy, name):
                self.A = A
                self.B = B
                self.P = P
                self.N = N
                self.Gx = Gx
                self.Gy = Gy
                self.name = name

        sm2p256v1 = CurveFp(
            name="sm2p256v1",
            A=0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC,
            B=0x28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93,
            P=0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF,
            N=0xFFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123,
            Gx=0x32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7,
            Gy=0xBC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0
        )

        def multiply(a, n, N, A, P):
            return fromJacobian(jacobianMultiply(toJacobian(a), n, N, A, P), P)

        def add(a, b, A, P):
            return fromJacobian(jacobianAdd(toJacobian(a), toJacobian(b), A, P), P)

        def inv(a, n):
            if a == 0:
                return 0
            lm, hm = 1, 0
            low, high = a % n, n
            while low > 1:
                r = high // low
                nm, new = hm - lm * r, high - low * r
                lm, low, hm, high = nm, new, lm, low
            return lm % n

        def toJacobian(Xp_Yp):
            Xp, Yp = Xp_Yp
            return (Xp, Yp, 1)

        def fromJacobian(Xp_Yp_Zp, P):
            Xp, Yp, Zp = Xp_Yp_Zp
            z = inv(Zp, P)
            return ((Xp * z ** 2) % P, (Yp * z ** 3) % P)

        def jacobianDouble(Xp_Yp_Zp, A, P):
            Xp, Yp, Zp = Xp_Yp_Zp
            if not Yp:
                return (0, 0, 0)
            ysq = (Yp ** 2) % P
            S = (4 * Xp * ysq) % P
            M = (3 * Xp ** 2 + A * Zp ** 4) % P
            nx = (M ** 2 - 2 * S) % P
            ny = (M * (S - nx) - 8 * ysq ** 2) % P
            nz = (2 * Yp * Zp) % P
            return (nx, ny, nz)

        def jacobianAdd(Xp_Yp_Zp, Xq_Yq_Zq, A, P):
            Xp, Yp, Zp = Xp_Yp_Zp
            Xq, Yq, Zq = Xq_Yq_Zq
            if not Yp:
                return (Xq, Yq, Zq)
            if not Yq:
                return (Xp, Yp, Zp)
            U1 = (Xp * Zq ** 2) % P
            U2 = (Xq * Zp ** 2) % P
            S1 = (Yp * Zq ** 3) % P
            S2 = (Yq * Zp ** 3) % P
            if U1 == U2:
                if S1 != S2:
                    return (0, 0, 1)
                return jacobianDouble((Xp, Yp, Zp), A, P)
            H = U2 - U1
            R = S2 - S1
            H2 = (H * H) % P
            H3 = (H * H2) % P
            U1H2 = (U1 * H2) % P
            nx = (R ** 2 - H3 - 2 * U1H2) % P
            ny = (R * (U1H2 - nx) - S1 * H3) % P
            nz = (H * Zp * Zq) % P
            return (nx, ny, nz)

        def jacobianMultiply(Xp_Yp_Zp, n, N, A, P):
            Xp, Yp, Zp = Xp_Yp_Zp
            if Yp == 0 or n == 0:
                return (0, 0, 1)
            if n == 1:
                return (Xp, Yp, Zp)
            if n < 0 or n >= N:
                return jacobianMultiply((Xp, Yp, Zp), n % N, N, A, P)
            if (n % 2) == 0:
                return jacobianDouble(jacobianMultiply((Xp, Yp, Zp), n // 2, N, A, P), A, P)
            if (n % 2) == 1:
                return jacobianAdd(jacobianDouble(jacobianMultiply((Xp, Yp, Zp), n // 2, N, A, P), A, P), (Xp, Yp, Zp),
                                   A, P)

        class PrivateKey:
            def __init__(self, curve=sm2p256v1, secret=None):
                self.curve = curve
                self.secret = secret or SystemRandom().randrange(1, curve.N)

            def publicKey(self):
                curve = self.curve
                xPublicKey, yPublicKey = multiply((curve.Gx, curve.Gy), self.secret, A=curve.A, P=curve.P, N=curve.N)
                return PublicKey(xPublicKey, yPublicKey, curve)

            def toString(self):
                return "{}".format(str(hex(self.secret))[2:].zfill(64))

        class PublicKey:
            def __init__(self, x, y, curve):
                self.x = x
                self.y = y
                self.curve = curve

            def toString(self, compressed=True):
                return {
                    True: str(hex(self.x))[2:],
                    False: "{}{}".format(str(hex(self.x))[2:].zfill(64), str(hex(self.y))[2:].zfill(64))
                }.get(compressed)

        def create_key_pair():
            priKey = PrivateKey()
            pubKey = priKey.publicKey()
            return priKey.toString(), pubKey.toString(compressed=False)

        # if __name__ == "__main__":
        priKey = PrivateKey()
        pubKey = priKey.publicKey()

        # 16进制的公钥和私钥
        private_key = priKey.toString()
        public_key = pubKey.toString(compressed=False)
        sm2_crypt = sm2.CryptSM2(
            public_key=public_key, private_key=private_key)
        '''
        # 数据加密后为bytes类型

        enc_data = sm2_crypt.encrypt(data)  # 密文
        # enc_data_str = codecs.decode(enc_data)
        # enc_data_str = str(enc_data, encoding="utf-8")
        # dec_data = sm2_crypt.decrypt(enc_data)
        # print("密文：", enc_data)
        # print("明文：", dec_data)
    else:
        # sm4
        key = ''.join(random.sample(string.ascii_letters + string.digits, 16))
        key = bytes(key, encoding="utf-8")
        value = data  # bytes类型
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key, SM4_ENCRYPT)
        enc_data = crypt_sm4.crypt_ecb(value)  # bytes类型
        # enc_data_str = codecs.decode(enc_data)
        # enc_data_str = str(enc_data, encoding="utf-8")
        # print(enc_data)
        # crypt_sm4.set_key(key, SM4_DECRYPT)
        # decrypt_value = crypt_sm4.crypt_ecb(encrypt_value) #  bytes类型
        # print(decrypt_value)
        # assert value == decrypt_value

    # ##########################################################################################################################
    # ##########################################################################################################################
    # ##########################################################################################################################

    prik = private_key
    pubk = public_key

    file = open("./Myapp/static/media/%s（公私钥对用以验签：第一行公，第二行私）.txt" % name[0:-4], "a+")
    file.write(pubk)  # 写入公钥
    file.write('\r\n')
    file.write(prik)  # 写入私钥

    # SM3加密函数

    data1 = data  # bytes类型明文
    data2 = enc_data  # bytes类型密文
    hash_data1 = sm3.sm3_hash(func.bytes_to_list(data1))
    hash_data2 = sm3.sm3_hash(func.bytes_to_list(data2))
    # 向数据库写入hash值
    User.objects.create(plaintext_hash=hash_data1, ciphertext_hash=hash_data2, model='sm%a' % mod)

    # 签名算法
    sign = sm2_crypt.sign(data, hash_data1)
    # sign = sm2_crypt.sign_with_sm3(data)

    file = open("./Myapp/static/media/%s（已加密）.txt" % name[0:-4], "ab+")  # 指定文件名和保存路径、文件操作类型、编码
    file.write(enc_data)  # 写入密文
    file = open("./Myapp/static/media/%s（已加密）.txt" % name[0:-4], "a+")
    file.write('\r\n')
    file.write(sign)  # 写入数字签名
    file.close()  # 关闭操作对象
    return render(request, 'process.html', context={'pubk': pubk, 'prik': prik, 'key': key})
