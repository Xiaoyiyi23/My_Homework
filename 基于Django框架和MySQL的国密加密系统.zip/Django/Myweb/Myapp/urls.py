# -*- codeing = utf-8 -*-
# @Time : 2022/7/1 20:46

from django.urls import path

from . import views

urlpatterns = [
    path('process', views.process, name='process'),
    path('', views.index, name='index'),
    path('sign', views.sign, name='sign'),
    path('testsign', views.testsign, name='testsign'),
]
